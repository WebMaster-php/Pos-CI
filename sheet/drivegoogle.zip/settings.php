<?php

/* Google App Client Id */
//define('CLIENT_ID', '1078281918055-jr0fofg0p67vs76q2898vqltuhrujul1.apps.googleusercontent.com');
define('CLIENT_ID', '581152888577-l13i1r3mtgc25m8tmusguvpki5mmbboa.apps.googleusercontent.com');

/* Google App Client Secret */
//define('CLIENT_SECRET', 'kC5lZwABIJ1BqkS8qHxFktu8');
define('CLIENT_SECRET', '_N3qvsTXsFnyZouZjieI-ioJ');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://localhost/drivegoogle/index.php');

?>